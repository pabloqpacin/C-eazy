from ws import WS_Server
import json
import time

NAME = 'my_esp8266'

## Client Mode
# WIFI_MODE = "sta"
# SSID = "YOUR SSID HERE"
# PASSWORD = "YOUR PASSWORD HERE"

## AP Mode
WIFI_MODE = "ap"
SSID = ""
PASSWORD = "12345678"


ws = WS_Server(name=NAME, mode=WIFI_MODE, ssid=SSID, password=PASSWORD)
ws.start()

def on_receive(data):
    print(data['H'])

    # output

    # input


ws.on_receive = on_receive

def main():
    print("start")
    while True:
        ws.loop()

main()